package com.training.mvc;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	@RequestMapping("/Hi")
	public String showPage() {
		return "main-menu";
	}
	
	@RequestMapping("/getData")
	public void getInput(@RequestParam("userName") String name){
		
		System.out.println("inside getInput method");
		System.out.println("name:"+name);
		
		
	}
	
}